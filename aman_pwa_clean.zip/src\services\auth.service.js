/**
 * AMAN · أمان - Authentication & Session Service
 * Secure password hashing via native `scrypt`, role checking & session management
 */

const { db } = require('../db/database');
const crypto = require('node:crypto');

class AuthService {
  /**
   * Hash password securely using scrypt with salt
   */
  hashPassword(password) {
    const salt = crypto.randomBytes(16).toString('hex');
    const derivedKey = crypto.scryptSync(password, salt, 64);
    return `${salt}:${derivedKey.toString('hex')}`;
  }

  /**
   * Verify password against hash
   */
  verifyPassword(password, storedHash) {
    if (!storedHash || !storedHash.includes(':')) return false;
    const [salt, key] = storedHash.split(':');
    const derivedKey = crypto.scryptSync(password, salt, 64);
    return crypto.timingSafeEqual(Buffer.from(key, 'hex'), derivedKey);
  }

  /**
   * Register a new user
   */
  register({ email, password, displayName, role = 'member' }) {
    if (!email || !password || !displayName) throw new Error('missing_fields');
    const existing = db.prepare('SELECT id FROM users WHERE email = ?').get(email.toLowerCase().trim());
    if (existing) throw new Error('email_exists');

    const id = 'u_' + Date.now() + '_' + crypto.randomBytes(4).toString('hex');
    const passwordHash = this.hashPassword(password);
    const cleanRole = ['member', 'ngo', 'lawyer', 'admin'].includes(role) ? role : 'member';
    const badge = cleanRole === 'admin' || cleanRole === 'ngo' ? 'verified' : 'person';

    db.prepare(`
      INSERT INTO users (id, email, password_hash, display_name, role, badge)
      VALUES (?, ?, ?, ?, ?, ?)
    `).run(id, email.toLowerCase().trim(), passwordHash, displayName.trim(), cleanRole, badge);

    return {
      id,
      email: email.toLowerCase().trim(),
      displayName: displayName.trim(),
      role: cleanRole,
      badge
    };
  }

  /**
   * Authenticate user login
   */
  login(email, password) {
    if (!email || !password) throw new Error('missing_credentials');
    const user = db.prepare('SELECT * FROM users WHERE email = ?').get(email.toLowerCase().trim());
    if (!user || !this.verifyPassword(password, user.password_hash)) {
      throw new Error('invalid_credentials');
    }

    return {
      id: user.id,
      email: user.email,
      displayName: user.display_name,
      role: user.role,
      badge: user.badge
    };
  }

  /**
   * Get public profile by ID
   */
  getUserById(id) {
    const user = db.prepare('SELECT id, email, display_name, role, badge, created_at FROM users WHERE id = ?').get(id);
    return user || null;
  }
}

module.exports = new AuthService();
