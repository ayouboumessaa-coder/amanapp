/**
 * AMAN · أمان - Community Service
 * Manages Posts, Comments, Likes, and Anonymity Enforcement via SQLite
 */

const { db } = require('../db/database');
const crypto = require('node:crypto');

class CommunityService {
  /**
   * Fetch Feed with filtering and search
   */
  getFeed({ category, search, page = 0, limit = 20 }) {
    let query = `
      SELECT p.*,
        (SELECT COUNT(*) FROM comments c WHERE c.post_id = p.id) as comments_count
      FROM posts p
      WHERE p.status = 'published'
    `;
    const params = [];

    if (category && category !== 'all') {
      query += ` AND p.category = ?`;
      params.push(category);
    }

    if (search && search.trim()) {
      query += ` AND (p.title LIKE ? OR p.body LIKE ?)`;
      const term = `%${search.trim()}%`;
      params.push(term, term);
    }

    query += ` ORDER BY p.created_at DESC LIMIT ? OFFSET ?`;
    params.push(limit, page * limit);

    const posts = db.prepare(query).all(...params);

    // Fetch comments for each post
    const getComments = db.prepare(`
      SELECT id, author_name as author, text, is_anonymous, created_at
      FROM comments
      WHERE post_id = ?
      ORDER BY created_at ASC
    `);

    return posts.map(p => ({
      id: p.id,
      author: p.author_name,
      badge: p.badge,
      isAnonymous: Boolean(p.is_anonymous),
      category: p.category,
      title: p.title,
      body: p.body,
      image: p.image_url,
      likes: p.likes_count,
      createdAt: p.created_at,
      comments: getComments.all(p.id)
    }));
  }

  /**
   * Create a new Post with guaranteed server-side anonymity protection
   */
  createPost({ authorName, isAnonymous = true, category = 'general', title, body, imageUrl = null }) {
    if (!title || !title.trim()) throw new Error('title_required');
    if (!body || !body.trim()) throw new Error('body_required');

    const cleanTitle = title.trim().slice(0, 200);
    const cleanBody = body.trim().slice(0, 15000);
    const id = 'p_' + Date.now() + '_' + crypto.randomBytes(4).toString('hex');

    // Strict anonymity scrub
    const isAnon = Boolean(isAnonymous);
    const finalAuthor = isAnon ? 'مشاركة خاصة (هوية محفوظة)' : (authorName?.trim() || 'عضوة مسجلة');
    const finalBadge = isAnon ? 'anonymous' : 'person';

    const stmt = db.prepare(`
      INSERT INTO posts (id, author_name, badge, is_anonymous, category, title, body, image_url, likes_count, status)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, 0, 'published')
    `);

    stmt.run(id, finalAuthor, finalBadge, isAnon ? 1 : 0, category, cleanTitle, cleanBody, imageUrl);

    return {
      id,
      author: finalAuthor,
      badge: finalBadge,
      isAnonymous: isAnon,
      category,
      title: cleanTitle,
      body: cleanBody,
      image: imageUrl,
      likes: 0,
      createdAt: new Date().toISOString(),
      comments: []
    };
  }

  /**
   * Toggle Like on a Post (persisted per user/client identifier)
   */
  toggleLike(postId, userIdentifier) {
    if (!postId || !userIdentifier) throw new Error('invalid_arguments');

    const existing = db.prepare('SELECT id FROM likes WHERE post_id = ? AND user_identifier = ?').get(postId, userIdentifier);

    if (existing) {
      db.prepare('DELETE FROM likes WHERE post_id = ? AND user_identifier = ?').run(postId, userIdentifier);
      db.prepare('UPDATE posts SET likes_count = MAX(0, likes_count - 1) WHERE id = ?').run(postId);
    } else {
      const id = 'l_' + Date.now() + '_' + crypto.randomBytes(4).toString('hex');
      db.prepare('INSERT INTO likes (id, post_id, user_identifier) VALUES (?, ?, ?)').run(id, postId, userIdentifier);
      db.prepare('UPDATE posts SET likes_count = likes_count + 1 WHERE id = ?').run(postId);
    }

    const post = db.prepare('SELECT likes_count FROM posts WHERE id = ?').get(postId);
    return {
      success: true,
      liked: !existing,
      likes: post ? post.likes_count : 0
    };
  }

  /**
   * Add a comment to a Post
   */
  addComment(postId, { authorName, text, isAnonymous = true }) {
    if (!postId || !text || !text.trim()) throw new Error('comment_text_required');

    const cleanText = text.trim().slice(0, 2000);
    const id = 'c_' + Date.now() + '_' + crypto.randomBytes(4).toString('hex');
    const isAnon = Boolean(isAnonymous);
    const finalAuthor = isAnon ? 'مشاركة مساندة' : (authorName?.trim() || 'عضوة أمان');

    const stmt = db.prepare(`
      INSERT INTO comments (id, post_id, author_name, is_anonymous, text)
      VALUES (?, ?, ?, ?, ?)
    `);

    stmt.run(id, postId, finalAuthor, isAnon ? 1 : 0, cleanText);

    return {
      id,
      postId,
      author: finalAuthor,
      text: cleanText,
      createdAt: new Date().toISOString()
    };
  }

  /**
   * Report a post for moderator review
   */
  reportPost(postId, reason, reporterIdentifier) {
    if (!postId || !reason) throw new Error('reason_required');
    const id = 'rep_' + Date.now() + '_' + crypto.randomBytes(4).toString('hex');
    db.prepare('INSERT INTO reports (id, post_id, reason, reporter_identifier) VALUES (?, ?, ?, ?)').run(
      id,
      postId,
      reason.trim().slice(0, 500),
      reporterIdentifier || 'anonymous'
    );
    return { success: true };
  }
}

module.exports = new CommunityService();
