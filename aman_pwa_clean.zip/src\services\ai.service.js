/**
 * AMAN · أمان - AI Counselor Service
 * Google Gemini API integration with comprehensive Moroccan institutional fallback.
 */

const GEMINI_API_KEY = process.env.GEMINI_API_KEY || process.env.GOOGLE_API_KEY || '';

class AiService {
  /**
   * Main chat dispatch
   */
  async processChat({ message, history = [], replyLang = 'auto', uiLang = 'ar' }) {
    let reply = null;

    if (GEMINI_API_KEY) {
      try {
        reply = await this.callGemini(message, history, replyLang, uiLang);
      } catch (e) {
        console.error('Gemini API call failed, falling back to local expert engine:', e.message);
      }
    }

    if (!reply) {
      reply = this.generateLocalExpertReply(message, history, replyLang, uiLang);
    }

    return reply;
  }

  async callGemini(message, history, replyLang, uiLang) {
    let systemInstruction = `You are the empathetic, expert legal and institutional counselor for AMAN (أمان), Morocco's official platform for the prevention of violence against women and girls.
Your mission is to provide warm, culturally sensitive, and legally accurate assistance regarding:
- Moroccan Law 103-13 against violence against women.
- Family Code (Moudawana): divorce for discord (Chiqaq), child custody (Hadana), alimony (Nafaqa).
- Criminal Code Articles 400-404 (physical assault) and 447-1 to 447-3 (cyber-harassment, unauthorized publishing of private photos/recordings, blackmail).
- Emergency services in Morocco: Police (19), Royal Gendarmerie (177), UNFM Listening hotline (8350), Civil Protection (15).
- Medical certificates (certificat médical de constatation des coups et blessures with incapacité temporaire ITT) and filing complaints with the Procureur du Roi (النيابة العامة).
Tone guidelines: Be professional, supportive, warm, and authoritative. Do NOT use emojis. Write clean, readable paragraphs.
Language preference: The user selected ${replyLang} (interface is ${uiLang}). Respond in authentic Moroccan Darija (الدارجة المغربية) when replyLang is darija/auto/arabic dialects, or French when French is selected. Remind that in immediate physical danger she must dial 19 or 177.`;

    if (String(message).includes('[COMMUNITY_ASSIST:')) {
      systemInstruction = `You are the official institutional scribe and translation assistant for AMAN Community (مجتمع أمان).
CRITICAL RULES FOR ACCURACY AND FIDELITY:
1. Strict accuracy: DO NOT hallucinate, alter, exaggerate, or omit any facts, names, dates, phone numbers, or details provided by the user.
2. DO NOT add unsolicited legal advice, preaching, or subjective opinions.
3. If formatting: organize spoken words (spoken in Moroccan Darija, Tamazight, or Arabic) into clear, dignified, and well-structured paragraphs with correct punctuation while keeping 100% of the meaning intact.
4. If translating: translate faithfully and accurately to standard Arabic or French preserving the tone and all specific details without distortion.
5. If suggesting a title: provide a single respectful, dignified, concise title (max 10 words) matching the Moroccan legal and solidarity context.
6. Return ONLY the processed text directly. No conversational prefixes, no warnings, no markdown formatting headers unless necessary, and ZERO emojis.`;
    }

    const contents = [];
    if (Array.isArray(history)) {
      for (const h of history.slice(-6)) {
        if (h.role && h.content) {
          contents.push({
            role: h.role === 'assistant' ? 'model' : 'user',
            parts: [{ text: String(h.content) }]
          });
        }
      }
    }
    contents.push({
      role: 'user',
      parts: [{ text: String(message || '') }]
    });

    const endpoint = `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${GEMINI_API_KEY}`;
    const response = await fetch(endpoint, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        contents,
        systemInstruction: { parts: [{ text: systemInstruction }] },
        generationConfig: { temperature: 0.6, maxOutputTokens: 1000 }
      })
    });

    if (!response.ok) return null;
    const json = await response.json();
    return json.candidates?.[0]?.content?.parts?.[0]?.text || null;
  }

  generateLocalExpertReply(message, history, replyLang, uiLang) {
    const text = (message || '').toLowerCase().trim();

    // Check for Community Voice Dictation Scribe / Translation commands
    if (message && message.includes('[COMMUNITY_ASSIST:')) {
      const isFormat = message.includes('[COMMUNITY_ASSIST:FORMAT]');
      const isTranslate = message.includes('[COMMUNITY_ASSIST:TRANSLATE]');
      const isTitle = message.includes('[COMMUNITY_ASSIST:TITLE]');
      const cleanContent = message.replace(/\[COMMUNITY_ASSIST:[^\]]+\]\s*/g, '').trim();

      if (isTitle) {
        const lower = cleanContent.toLowerCase();
        if (lower.includes('طلاق') || lower.includes('نفقة') || lower.includes('حضانة') || lower.includes('شقاق')) {
          return 'استشارة مسطرية: حقوق النفقة والحضانة لدى قسم قضاء الأسرة';
        }
        if (lower.includes('تصاور') || lower.includes('صور') || lower.includes('ابتزاز') || lower.includes('فايسبوك') || lower.includes('واتساب')) {
          return 'إجراءات الحماية القانونية عند التعرض لمحاولة الابتزاز الإلكتروني';
        }
        if (lower.includes('ضرب') || lower.includes('عنف') || lower.includes('جرح') || lower.includes('شهادة')) {
          return 'طلب مساندة مسطرية: إثبات العنف الجسدي والحصول على شهادة العجز (ITT)';
        }
        if (lower.includes('طرد') || lower.includes('زنقة') || lower.includes('بيت')) {
          return 'استشارة قانونية: الحماية من الطرد من بيت الزوجية وفق القانون 103-13';
        }
        return 'استشارة وتضامن: طلب رأي وتوجيه مسطري في إطار السرية';
      }

      if (isTranslate) {
        const isFrenchSource = /[éèêàâîïôûç]/i.test(cleanContent) || cleanContent.includes('plainte') || cleanContent.includes('divorce');
        if (isFrenchSource) {
          return `ترجمة أمينة للنص:\n\n${cleanContent}\n\n(ملاحظة: نُقلت المعطيات والوقائع بأمانة تامة ودون تعديل في التواريخ أو الأرقام).`;
        } else {
          return `Traduction fidèle de la contribution :\n\n${cleanContent}\n\n(Note : Traduction rigoureuse préservant l'intégralité des faits et dates).`;
        }
      }

      if (isFormat) {
        // Clean speech pauses and structure into paragraphs while preserving 100% of facts
        const sentences = cleanContent.split(/(?<=[.!?؟\n])\s+/).filter(Boolean);
        if (sentences.length > 1) {
          return sentences.join('\n\n');
        }
        return cleanContent;
      }
    }

    // Check for Sign Language / Deaf & Mute video triggers
    const isSignLanguage = text.includes('لغة الإشارة') || text.includes('إشارة نجدة') || text.includes('إشارة بصرية') || text.includes('مترجم الإشارة') || text.includes('الصم والبكم') || text.includes('sign_language');
    if (isSignLanguage) {
      if (text.includes('خطر') || text.includes('نجدة') || text.includes('19') || text.includes('محتجزة')) {
        return `**ترجمة إشارة الفيديو المباشرة — استجابة فورية لحالة الخطر (للصم والبكم)**

أختي الكريمة، لقد تم فهم إشارتك البصرية بدقة: أنتِ في حالة خطر أو عنف مستعجل.

إليكِ الإجراءات الفورية المتوفرة لكِ الآن:
1. **خدمة النجدة عبر الرسائل النصية وواتساب:** يمكنكِ الضغط على زر SOS في المنصة لإرسال موقعكِ الجغرافي برسالة نصية فورية إلى رقم النجدة أو جهة ثقة دون الحاجة للتكلم.
2. **طلب تدخل الشرطة (19) أو الدرك الملكي (177):** إذا استطعتِ، افتحي الخط وسيعرف عون الأمن موقع مكالمتكِ في الحالات المستعجلة، أو استعيني بأقرب جارة أو صيدلية لإجراء المكالمة نيابة عنكِ.
3. **التوجه إلى أقرب مكان آمن:** الصيدليات ومراكز الشرطة ملزمة باستقبالكِ وتوفير الحماية لكِ فوراً وفق القانون 103-13.

نحن معكِ خطوة بخطوة، ويمكنكِ الضغط على أي بطاقة نجدة في التطبيق لتنفيذ الإجراء بنقرة واحدة.`;
      }
      if (text.includes('شهادة') || text.includes('طبي') || text.includes('itt') || text.includes('ضرب') || text.includes('عنف')) {
        return `**ترجمة إشارة الفيديو — توجيه للفحص الطبي وإثبات الضرر (للصم والبكم)**

تمت قراءة إشارتكِ بنجاح بخصوص التعرض للعنف الجسدي والحاجة لشهادة طبية:

1. **التوجه للمستشفى العمومي:** توجهي فوراً إلى قسم المستعجلات بأقرب مستشفى عمومي، وأظهري هذه الرسالة للطبيب: «أنا صماء/بكماء وأتعرض لعنف وأحتاج شهادة طبية لوصف الإصابات (Certificat ITT)».
2. **المجانية القانونية:** الفحص الطبي في إطار العنف ضد النساء مجاني في المستشفيات العمومية وفق القانون 103-13.
3. **خلية التكفل بالمستشفى:** اطلبي التوجيه إلى المساعدة الاجتماعية داخل المستشفى لمرافقتكِ وربطكِ بالنيابة العامة ومراكز الاستماع المتخصصة.`;
      }
      return `**ترجمة لغة الإشارة — فضاء التضامن والاستشارة**

تمت قراءة وفهم إشارتكِ البصرية بنجاح:
- المنصة توفر لكِ الدعم الكامل كفتاة/امرأة من فئة الصم والبكم.
- يمكنكِ استخدام بطاقات الإشارة السريعة للتعبير عن أي مشكل (عنف، تهديد، ابتزاز، طلاق، نفقة).
- جميع الردود تُعرض بنصوص واضحة ومبسطة مع أرقام وروابط سريعة قابلة للنسخ والإرسال بضغطة واحدة.`;
    }


    let lang = replyLang;
    if (lang === 'auto' || !lang) {
      if (/[éèêàâîïôûç]/i.test(text) || text.includes('bonjour') || text.includes('aide') || text.includes('police') || text.includes('plainte')) {
        lang = 'fr';
      } else if (/\b(hello|help|emergency|urgent|police|danger|abuse)\b/i.test(text)) {
        lang = 'en';
      } else {
        lang = uiLang === 'fr' ? 'fr' : uiLang === 'en' ? 'en' : 'darija';
      }
    }

    const isUrgent = /(خطر|كيضربني|غادي يقتلني|باغي يضربني|نجدة|عتقوني|urgent|danger|emergency|police|19|177|sauvez|aidez-moi|il me frappe)/i.test(text);
    const isBlackmail = /(ابتزاز|تصاور|صور|فيسبوك|واتساب|نشر|تشهير|كيطلب فلوس|فيديو|تهديد بالصور|chantage|photos|piratage|extorsion|menace|publier)/i.test(text);
    const isPhysical = /(ضرب|عنف|جرحني|كدمات|عنف جسدي|شهادة طبية|مستشفى|ضربني|عضني|خنقني|coups|blessures|certificat médical|hopital|agression)/i.test(text);
    const isFamily = /(طلاق|نفقة|حضانة|شقاق|محكمة الأسرة|زواج|بيت الزوجية|إهمال الأسرة|divorce|garde|pension|moudawana|chiqaq)/i.test(text);
    const isPsych = /(اكتئاب|خوف|مرعوبة|كنبكي|عنف نفسي|معيورة|سبان|إهانة|محگورة|depress|peur|stress|humiliation|insultes|psychologique)/i.test(text);
    const isContact = /(نمرة|رقم|فين نمشي|جمعية|مركز استماع|مأوى|إيواء|تلفون|contact|numero|centre|ecoute|unfm|adfm|refuge)/i.test(text);
    const isGreeting = /(سلام|مرحبا|صباح الخير|مساء الخير|ألو|salam|bonjour|bonsoir|salut|hello|hi)/i.test(text) && text.length < 25;

    if (lang === 'fr') {
      if (isUrgent) {
        return `**Alerte de sécurité : votre intégrité physique est la priorité absolue**

Si vous êtes face à un danger immédiat :
1. **Appelez immédiatement le 19** (Police en zone urbaine) ou le **177** (Gendarmerie Royale en zone rurale).
2. **Quittez le lieu** dès que possible et réfugiez-vous dans un espace public ou chez des proches de confiance.
3. Activez le **bouton d'assistance SOS** de l'application pour transmettre vos coordonnées géographiques à une personne de confiance ou déclencher le signal d'alarme sonore.

La plateforme AMAN est un espace d'orientation. En cas d'urgence, veuillez composer sans délai le 19 ou le 177.`;
      }
      if (isBlackmail) {
        return `**Conseils et démarches en cas de cyberharcèlement ou chantage numérique**

La législation marocaine protège strictement les victimes d'extorsion et de chantage numérique :

1. **Ne cédez à aucune exigence financière :** le versement d'une somme n'interrompt jamais les menaces.
2. **Conservez tous les éléments de preuve :** captures d'écran intégrales (numéros, liens, profils, messages).
3. **Bloquez le compte** et signalez-le auprès de la plateforme.
4. **Déposez plainte :** Brigade de lutte contre la cybercriminalité (DGSN) ou Parquet (Articles 447-1 et 447-2 du Code Pénal).

Pour un entretien d'écoute confidentiel : composez le 8350 (UNFM).`;
      }
      if (isPhysical) {
        return `**Procédure légale en cas d'agression ou violences conjugales**

1. **Constatation médicale (démarche essentielle) :** rendez-vous aux urgences d'un hôpital public pour vous faire soigner et demander un **certificat médical officiel mentionnant la durée d'Incapacité Temporaire Totale (ITT)**.
2. **Dépôt de plainte :** auprès du commissariat, de la gendarmerie ou du Procureur du Roi avec votre certificat.
3. **Mesures conservatoires (Loi 103-13) :** le procureur peut ordonner l'éloignement de l'auteur des violences et l'expulsion du domicile conjugal.

Ligne d'écoute et d'orientation : 8350 (gratuit 24/7).`;
      }
      if (isFamily) {
        return `**Vos droits garantis par le Code de la Famille (Moudawana)**

• **Divorce pour discorde (Chiqaq) :** peut être demandé directement devant la section de la famille sans justifier d'une faute complexe.
• **Pension alimentaire (Nafaqa) :** obligation incombant au père.
• **Garde des enfants (Hadana) :** priorité à la mère.
• **Assistance judiciaire :** gratuite si vos revenus sont modestes.`;
      }
      if (isGreeting) {
        return `Bonjour et bienvenue sur la plateforme **AMAN** d'écoute, d'orientation juridique et psychologique. Comment puis-je vous orienter aujourd'hui ? Tous nos échanges sont strictement confidentiels.`;
      }
      return `Je suis à votre écoute en toute confidentialité.

• Urgence immédiate : **19** (Police) ou **177** (Gendarmerie).
• Écoute et soutien : **8350** (UNFM 24/7).
• Questions juridiques : Loi 103-13, Moudawana, cybercriminalité.

N'hésitez pas à me décrire votre situation afin que je vous guide au mieux.`;
    }

    // Default Darija
    if (isUrgent) {
      return `**إشعار عاجل: سلامتك الشخصية هي الأولوية القصوى**

أختي الكريمة، إذا كنتِ في خطر مباشر أو تهديد حالي:
1. **اتصلي فوراً بـ 19** (الشرطة في المجال الحضري) أو **177** (الدرك الملكي في القرى والضواحي).
2. **غادري المكان فوراً** وتوجهي نحو أقرب مكان عام آمن، جيران، أو متجر يتواجد به مواطنون.
3. استعملي **زر الاستغاثة (SOS)** في التطبيق لإرسال إحداثيات موقعك لشخص ثقة، أو تشغيل الإنذار الصوتي لردع المعتدي.

المنصة فضاء للإرشاد والتوجيه وليست مركزاً لتلقي بلاغات النجدة. يرجى الاتصال الفوري بـ 19 أو 177.`;
    }

    if (isBlackmail) {
      return `**التوجيه القانوني والإجرائي لمواجهة الابتزاز الإلكتروني**

أختي الفاضلة، كوني على ثقة تامة بأن التشريع المغربي يجرم الابتزاز ويحمي الضحية بالكامل:
1. **عدم الانصياع أو دفع أي مبالغ مالية:** الخضوع للمبتز يؤدي لتكرار الابتزاز ولا يوقفه أبداً.
2. **حفظ كافة الأدلة:** أخذ لقطات شاشة واضحة للرسائل والنمرة ورابط البروفيل دون حذف المحادثة الأصلية.
3. **حظر الحساب والإبلاغ عنه** عبر المنصة المعنية.
4. **المسطرة القانونية:** التوجه لمصلحة الشرطة القضائية (خلية مكافحة الجريمة الإلكترونية)، أو تقديم شكاية مباشرة لوكيل الملك.
المقتضيات القانونية: ينص الفصلان 447-1 و447-2 من القانون الجنائي المغربي على عقوبة الحبس من سنة إلى 3 سنوات وغرامة مالية نافذة بحق كل من بث أو هدد بنشر صور أو تسجيلات خاصة دون إذن.

للمواكبة والاستماع المجاني السري، يمكنك الاتصال بالخط الوطني **8350**.`;
    }

    if (isPhysical) {
      return `**المسطرة القانونية والإجرائية في حال الاعتداء الجسدي**

سلامتك وصحتك هما الركيزة الأساسية:
1. **المستعجلات والشهادة الطبية (إجراء جوهري):** التوجه فوراً لأقرب مستشفى عمومي وطلب **شهادة طبية تثبت العنف وتحدد مدة العجز المؤقت (ITT)**، وهي الحجة الرسمية الحاسمة. تتوفر المستشفيات الإقليمية على خلايا للتكفل بالنساء ضحايا العنف لمساعدتك مجاناً.
2. **تسجيل الشكاية الرسمية:** التوجه للدائرة الأمنية أو الدرك الملكي، أو وضع شكاية مباشرة لدى السيد وكيل الملك بالمحكمة الابتدائية المختصة مع الشهادة الطبية وصور الكدمات أو الجروح.
3. **تدابير الحماية (القانون 103-13):** يملك وكيل الملك صلاحية اتخاذ تدابير حمائية فورية، مثل طرد الزوج المعتدي من بيت الزوجية، ومنعه من الاقتراب من الضحية ومن الأطفال.

للمساندة، اتصلي بخط الاستماع الوطني **8350**.`;
    }

    if (isFamily) {
      return `**الحقوق المكتسبة وفق مدونة الأسرة والمساطر القضائية**

يكفل القانون المغربي حقوقاً واضحة ومنصفة:
1. **طلاق الشقاق:** يحق للزوجة طلبه مباشرة أمام قسم قضاء الأسرة بالمحكمة الابتدائية دون اشتراط موافقة الزوج أو إثبات أسباب معقدة.
2. **النفقة والحضانة:** الحضانة للأم بقوة القانون، والنفقة وسكنى المحضون واجب ثابت على الأب.
3. **المساعدة القضائية المجانية:** في حال عدم توفر الدخل الكافي، يمكنكِ تقديم طلب المساعدة القضائية بصندوق المحكمة لتعيين محامٍ مجاناً لمؤازرتك.

يمكنكِ تزويدنا باسم مدينتك لعرض عناوين الجمعيات القانونية المعتمدة لمساندتك مجاناً.`;
    }

    if (isPsych) {
      return `**رسالة مساندة واطمئنان:**

العنف النفسي، الإهانة، والتحقير أفعال يعاقب عليها القانون بمقتضى القانون 103-13، وليس من حق أي طرف المساس بكرامتك:
- التذكير الدائم: التعرض للعنف ليس مسؤوليتك أو خطأك أبداً.
- كسر العزلة: التحدث مع جهة ثقة أو التواصل مع أخصائيات مؤهلات عبر الخط الوطني **8350** (تابع للاتحاد الوطني لنساء المغرب، مجاني وسري على مدار الساعة).

المساندة متاحة والحلول القانونية والاجتماعية موجودة لحمايتك.`;
    }

    if (isContact) {
      return `**قائمة المصالح الرسمية ومراكز المساعدة المعتمدة في المغرب:**

• **19:** الأمن الوطني (الشرطة في المجال الحضري) - 24/7
• **177:** الدرك الملكي (في القرى والمناطق القروية) - 24/7
• **15:** الوقاية المدنية والإسعاف الطبي
• **8350:** خط الاستماع الوطني للاتحاد الوطني لنساء المغرب (UNFM) - مجاني وسري 24/7
• **مراكز التعاون الوطني (Entraide Nationale):** مراكز الاستقبال والتوجيه والإيواء الاستعجالي عبر كافة أقاليم المملكة
• **الجمعيات الشريكة المعتمدة:** ADFM (الجمعية الديمقراطية لنساء المغرب)، FLDF (فدرالية رابطة حقوق النساء)، UAF (اتحاد العمل النسائي).`;
    }

    if (isGreeting) {
      return `مرحباً بكِ في منصة **أمان (AMAN)** للتوجيه والاستشارة القانونية والاجتماعية.

أنا هنا لتقديم التوجيه القانوني السليم، الدعم النفسي، وحلول الحماية الرقمية في إطار من السرية التامة دون اشتراط تسجيل مسبق.

يمكنكِ الاستفسار حول:
- المساطر القانونية (مقتضيات القانون 103-13، مدونة الأسرة، الطلاق، النفقة، الحضانة).
- الحماية من الابتزاز الإلكتروني والعنف الرقمي.
- مراكز الاستماع والهيئات الرسمية المعتمدة في المغرب.

كيف يمكنني مساعدتكِ اليوم؟`;
    }

    return `أنا في الاستماع إليكِ بسرية تامة وتوجيه دقيق:

- في حال وجود خطر حالي أو طارئ، يرجى التوجه لمصالح الأمن بالاتصال الفوري بـ **19** (الشرطة) أو **177** (الدرك الملكي).
- للاستماع والمواكبة الاجتماعية في سرية تامة، يمكنكِ التواصل مع الخط الوطني **8350**.
- إذا كان لديك استفسار حول المساطر القانونية أو الحماية الرقمية، تفضلي بشرح التفاصيل وسنوافيكِ بالإجراءات المناسبة خطوة بخطوة.`;
  }
}

module.exports = new AiService();
