/**
 * AMAN · أمان - Security Middleware & Protection
 * Rate limiting, security headers, input sanitizers & audit logging
 */

const { db } = require('../db/database');
const crypto = require('node:crypto');

// In-memory sliding window rate limiter
const rateLimits = new Map();

class SecurityMiddleware {
  /**
   * Apply institutional security headers
   */
  applySecurityHeaders(res) {
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('X-Frame-Options', 'SAMEORIGIN');
    res.setHeader('X-XSS-Protection', '1; mode=block');
    res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
    res.setHeader('Permissions-Policy', 'geolocation=(self), microphone=(self), camera=()');
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  }

  /**
   * Rate limiting by client IP
   * @param {string} ip Client IP address
   * @param {number} maxRequests Maximum allowed requests in window
   * @param {number} windowMs Time window in milliseconds
   */
  checkRateLimit(ip, maxRequests = 60, windowMs = 60000) {
    const now = Date.now();
    const clientKey = ip || 'unknown';

    if (!rateLimits.has(clientKey)) {
      rateLimits.set(clientKey, []);
    }

    const timestamps = rateLimits.get(clientKey).filter(ts => now - ts < windowMs);
    timestamps.push(now);
    rateLimits.set(clientKey, timestamps);

    if (timestamps.length > maxRequests) {
      return false; // Rate limit exceeded
    }
    return true;
  }

  /**
   * Sanitize text against XSS and control characters
   */
  sanitizeText(str) {
    if (typeof str !== 'string') return '';
    return str
      .replace(/[<>]/g, '')
      .replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, '')
      .trim();
  }

  /**
   * Record security or administrative audit log
   */
  logAudit(eventType, details, ip) {
    try {
      const id = 'aud_' + Date.now() + '_' + crypto.randomBytes(4).toString('hex');
      const ipHash = ip ? crypto.createHash('sha256').update(ip).digest('hex').slice(0, 16) : null;
      db.prepare(`
        INSERT INTO audit_logs (id, event_type, details, ip_hash)
        VALUES (?, ?, ?, ?)
      `).run(id, eventType, JSON.stringify(details), ipHash);
    } catch (e) {
      console.error('Audit log failed:', e.message);
    }
  }
}

module.exports = new SecurityMiddleware();
