/**
 * AMAN · أمان - Database Layer
 * Native SQLite Engine via Node.js v24 `node:sqlite`
 * Zero external dependencies, persistent WAL mode, automatic migrations & seeding.
 */

const { DatabaseSync } = require('node:sqlite');
const fs = require('node:fs');
const path = require('node:path');

const DATA_DIR = path.join(__dirname, '..', '..', 'data');
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

const DB_PATH = path.join(DATA_DIR, 'aman.db');
const db = new DatabaseSync(DB_PATH);

// Enable WAL mode for high performance and integrity
db.exec('PRAGMA journal_mode = WAL;');
db.exec('PRAGMA foreign_keys = ON;');

/**
 * Initialize Tables & Migrations
 */
function initDatabase() {
  db.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id TEXT PRIMARY KEY,
      email TEXT UNIQUE,
      password_hash TEXT,
      display_name TEXT NOT NULL,
      role TEXT NOT NULL DEFAULT 'member', -- member, ngo, lawyer, admin
      badge TEXT DEFAULT 'person',        -- person, verified, anonymous
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS posts (
      id TEXT PRIMARY KEY,
      author_id TEXT,
      author_name TEXT NOT NULL,
      badge TEXT DEFAULT 'anonymous',
      is_anonymous INTEGER NOT NULL DEFAULT 1,
      category TEXT NOT NULL DEFAULT 'general',
      title TEXT NOT NULL,
      body TEXT NOT NULL,
      image_url TEXT,
      likes_count INTEGER NOT NULL DEFAULT 0,
      status TEXT NOT NULL DEFAULT 'published', -- published, pending, flagged
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS comments (
      id TEXT PRIMARY KEY,
      post_id TEXT NOT NULL,
      author_id TEXT,
      author_name TEXT NOT NULL,
      is_anonymous INTEGER NOT NULL DEFAULT 1,
      text TEXT NOT NULL,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (post_id) REFERENCES posts(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS likes (
      id TEXT PRIMARY KEY,
      post_id TEXT NOT NULL,
      user_identifier TEXT NOT NULL,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      UNIQUE(post_id, user_identifier),
      FOREIGN KEY (post_id) REFERENCES posts(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS reports (
      id TEXT PRIMARY KEY,
      post_id TEXT NOT NULL,
      reason TEXT NOT NULL,
      reporter_identifier TEXT NOT NULL,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (post_id) REFERENCES posts(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS audit_logs (
      id TEXT PRIMARY KEY,
      event_type TEXT NOT NULL,
      details TEXT NOT NULL,
      ip_hash TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE INDEX IF NOT EXISTS idx_posts_category ON posts(category);
    CREATE INDEX IF NOT EXISTS idx_posts_created ON posts(created_at DESC);
    CREATE INDEX IF NOT EXISTS idx_comments_post ON comments(post_id);
    CREATE INDEX IF NOT EXISTS idx_likes_post ON likes(post_id);
  `);

  // Seed default official guidance posts if empty
  const countRow = db.prepare('SELECT COUNT(*) as cnt FROM posts').get();
  if (countRow.cnt === 0) {
    seedDefaultPosts();
  }
}

function seedDefaultPosts() {
  const insertPost = db.prepare(`
    INSERT INTO posts (id, author_id, author_name, badge, is_anonymous, category, title, body, likes_count, created_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);

  const insertComment = db.prepare(`
    INSERT INTO comments (id, post_id, author_id, author_name, is_anonymous, text, created_at)
    VALUES (?, ?, ?, ?, ?, ?, ?)
  `);

  const now = Date.now();

  // Post 1: Confidential Legal Inquiry
  insertPost.run(
    'p_seed_0',
    null,
    'مشاركة خاصة (هوية محفوظة)',
    'anonymous',
    1,
    'legal',
    'استفسار عاجل حول مسطرة طلاق الشقاق ومستحقات الحضانة والنفقة',
    'أخواتي الفاضلات، طرحت استشارتي هنا بهوية محفوظة لضمان السرية. أتعرض لضغوط وعنف لفظي مستمر وأود معرفة الإجراءات العملية لطلاق الشقاق لدى قسم قضاء الأسرة بالمحكمة الابتدائية، خاصة فيما يتعلق بضمان سكنى المحضون والنفقة الشهرية للطفلتين. أرجو التوجيه القانوني السليم من ذوات التجربة أو الأخصائيات.',
    38,
    new Date(now - 3600000 * 3).toISOString()
  );

  insertComment.run(
    'c_seed_01',
    'p_seed_0',
    null,
    'خلية الاستماع والمواكبة القانونية',
    0,
    'أختي الكريمة، مسطرة طلاق الشقاق وفق مدونة الأسرة ترفع بمقال افتتاحي أمام قسم قضاء الأسرة ولا تلزمك بموافقة الزوج. المحكمة تقضي بوجوب توفير سكنى المحضون ونفقة الأطفال كحق ثابت بقوة القانون. يمكنك أيضاً طلب المساعدة القضائية المجانية.',
    new Date(now - 3600000 * 2).toISOString()
  );

  insertComment.run(
    'c_seed_02',
    'p_seed_0',
    null,
    'أمينة ب.',
    0,
    'عن تجربة شخصية، أنصحك أيضاً بالاتصال بالرقم المجاني 8350 التابع للاتحاد الوطني لنساء المغرب، حيث يقدمون مواكبة متكاملة خطوة بخطوة.',
    new Date(now - 3600000 * 1).toISOString()
  );

  // Post 2: Physical Abuse & Hospital Certificate
  insertPost.run(
    'p_seed_1',
    null,
    'خلية الاستماع والمساعدة الاجتماعية',
    'verified',
    0,
    'legal',
    'التدابير القانونية والإجرائية الفورية عند التعرض للاعتداء الجسدي',
    'تذكيراً بالإجراءات الرسمية المعتمدة لحماية النساء:\n1. التوجه مباشرة إلى قسم المستعجلات بالمستشفى العمومي للحصول على الشهادة الطبية التي تحدد مدة العجز (ITT)، وهي الوثيقة الجوهرية لإثبات الاعتداء.\n2. إيداع الشكاية لدى الدائرة الأمنية أو مصالح الدرك الملكي، أو مباشرة لدى السيد وكيل الملك.\n3. يخول القانون 103-13 للنيابة العامة اتخاذ تدابير حمائية عاجلة، منها طرد المعتدي من بيت الزوجية ومنعه من الاقتراب من الضحية.\nخطوط الطوارئ 19 و 177 في خدمتكن على مدار الساعة.',
    64,
    new Date(now - 3600000 * 24 * 2).toISOString()
  );

  // Post 3: Cybercrime & Blackmail
  insertPost.run(
    'p_seed_2',
    null,
    'فريق الأمان الرقمي AMAN',
    'verified',
    0,
    'safety',
    'الدليل الإجرائي لمواجهة الابتزاز الإلكتروني والتهديد بنشر المعطيات الخاصة',
    'في حال التعرض لأي محاولة ابتزاز أو تهديد بنشر محادثات أو صور خاصة:\n1. عدم الاستجابة لأي طلب مالي، لأن الخضوع للمبتز يؤدي لتكرار المطالب.\n2. حفظ الأدلة الفنية: أخذ لقطات شاشة واضحة للمحادثات، أرقام الهواتف، وروابط الحسابات دون حذفها.\n3. التقدم بشكاية لدى المصلحة الولائية للشرطة القضائية (خلية مكافحة الجريمة الإلكترونية التابعة لـ DGSN).\nتنص الفصول 447-1 وما يليها من القانون الجنائي على عقوبات حبسية تتراوح بين سنة وثلاث سنوات وغرامات مالية نافذة بحق مرتكبي هذه الأفعال.',
    98,
    new Date(now - 3600000 * 24 * 5).toISOString()
  );
}

initDatabase();

module.exports = {
  db,
  initDatabase
};
