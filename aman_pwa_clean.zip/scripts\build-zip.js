const fs = require('node:fs');
const path = require('node:path');
const { execSync } = require('node:child_process');

const rootDir = path.join(__dirname, '..');
const tempDir = path.join(rootDir, '..', 'aman_pwa_pkg_temp');
const outZip = path.join(rootDir, '..', 'aman_pwa_clean.zip');

if (fs.existsSync(tempDir)) fs.rmSync(tempDir, { recursive: true, force: true });
fs.mkdirSync(tempDir, { recursive: true });

function copyFiltered(src, dst) {
  const entries = fs.readdirSync(src, { withFileTypes: true });
  for (const entry of entries) {
    const srcPath = path.join(src, entry.name);
    const dstPath = path.join(dst, entry.name);

    if (entry.name.endsWith('-wal') || entry.name.endsWith('-shm') || entry.name === 'node_modules') continue;

    if (entry.isDirectory()) {
      fs.mkdirSync(dstPath, { recursive: true });
      copyFiltered(srcPath, dstPath);
    } else {
      fs.copyFileSync(srcPath, dstPath);
    }
  }
}

copyFiltered(rootDir, tempDir);

try {
  execSync(`powershell -Command "Compress-Archive -Path '${tempDir}\\*' -DestinationPath '${outZip}' -Force"`);
  console.log('Clean distribution ZIP created successfully:', outZip);
} finally {
  fs.rmSync(tempDir, { recursive: true, force: true });
}
